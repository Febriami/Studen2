package com.insiteprojectid.student2;

        import android.os.Bundle;
        import android.support.v7.app.AppCompatActivity;
        import android.widget.ListView;

        import com.insiteprojectid.student2.adapter.StudentArrayAdapter;
        import com.insiteprojectid.student2.user.Lecture;

        import java.util.ArrayList;

public class LectureActivity extends AppCompatActivity {
        private  LectureArrayAdapter lectureArrayAdapter;
        private list_view;
        private TextView emptyTexView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.lecture_insctace);

        LectureArrayAdapter lectureArrayAdapter = new LectureArrayAdapter(this,lecture);
        List_item = (ListView) findViewById(R.id.list_item);
        List_item.setAdapter(LectureArrayAdapter);
        emptyTexView = (TextView) findViewById(R.Id.empty_view);
        List_Item .setEmptyView(emptyTexView);
        floatingActionButton addButton = (FloatingActionButton) findViewById(R.id.addButton);
        lectureView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(LectureActivity.this,AddLecture.class);
                startActivity(intent);
            }
        });
    }

    private ArrayList<Lecture> populateLectureDummies(){
        ArrayList<Lecture> studentList = new ArrayList<Lecture>();
        studentList.add(new Lecture(1,"3145136188","TRI FEBRIANA SIAMI","0858xxxxxx","tri@mhs.unj.ac.id"));
        studentList.add(new Lecture(2,"3145136192","Ummu Kultsum","0813xxxxxx","ummu@mhs.unj.ac.id"));
        return studentList;
    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu_list_student,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        switch(item.getItemId()){
            case R.id.create_dummy:
                populateLectureDummies();
                return true;
            case R.id.clear_list:
                LectureList.getInstance().clearList();
                LectureArrayAdapter = new LectureArrayAdapter(this, new ArrayList<Lecture>());
                LectureListView.setAdapter(LectureArrayAdapter);
                return true;
        }

        return super.onOptionsItemSelected(item);
    }

}
