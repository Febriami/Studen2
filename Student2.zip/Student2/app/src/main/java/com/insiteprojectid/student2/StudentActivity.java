package com.insiteprojectid.student2;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;


import com.insiteprojectid.student2.adapter.StudentArrayAdapter;
import com.insiteprojectid.student2.user.Student;


import java.util.ArrayList;

public class StudentActivity extends AppCompatActivity {
    private StudentArrayAdapter studentArrayAdapter;
    private list_view;
    private TextView emptyTexView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_view);

        //ArrayList<Student> students = populateStudentDummies();
        StudentArrayAdapter studentArrayAdapter = new StudentArrayAdapter(this,student);
        List_Item = (ListView) findViewById(R.id.list_item);
        List_Item.setAdapter(studentArrayAdapter);
        emptyTexView = (TextView) findViewById(R.Id.empty_view);
        List_Item .setEmptyView(emptyTexView);
        floatingActionButton addButton = (FloatingActionButton) findViewById(R.id.addButton);
        addButton.setOnClikListener(new View.OnClikListener(){
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(StudentActivity.this,AddStudent.class);
                startActivity(intent);
            }
        });
    }

    private ArrayList<Student> populateStudentDummies(){
        ArrayList<Student> studentList = new ArrayList<Student>();
        studentList.add(new Student(1,"3145136188","TRI FEBRIANA SIAMI","0858xxxxxx","tri@mhs.unj.ac.id"));
        studentList.add(new Student(2,"3145136192","Ummu Kultsum","0813xxxxxx","ummu@mhs.unj.ac.id"));
        return studentList;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu_list_student,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        switch(item.getItemId()){
            case R.id.create_dummy:
                populateStudentDummies();
                return true;
            case R.id.clear_list:
                StudentList.getInstance().clearList();
                studentArrayAdapter = new StudentArrayAdapter(this, new ArrayList<Student>());
                studentListView.setAdapter(studentArrayAdapter);
                return true;
        }

        return super.onOptionsItemSelected(item);
    }
}